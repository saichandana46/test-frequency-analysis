from collections import Counter
from datetime import datetime
from typing import Union
import json
import os
import re


# read file
def read_file(input_arg) -> str:
    try:
        doc = input(input_arg)
        ext = tuple([".txt", ".pdf"])
        if doc.endswith(ext):
            with open(doc, "r") as f:
                f_read = f.read().strip()
            return f_read
        else:
            raise Exception("File format not supported")
    except Exception as e:
        print(e)


# function to process words(stopwords, stemming of words)
def process_words(sw, words) -> dict:
    try:
        words, sw_flag = process_stopwords(sw, words)
        d, stem_flag = stem_words(words)
        return dict(Counter(d).most_common(25)), sw_flag, stem_flag
    except Exception as e:
        print("Exception in processing words: ", e)


# find frequencies of word after applying settings like stopwords and stemming of words
def freq_analysis() -> None:
    try:
        # options for the user to perform an operation
        switch_options = {
            "0": "Perform word frequency analysis with fresh data? ",
            "1": "Continue a new analysis with the current data?",
            "2": "List previous analyses",
            "3": "Exit out of the analysis",
        }
        # check if file has contents
        # read original text document
        f_read = read_file("Enter a text document: ")
        if f_read:
            # exclude non-letter characters, include only alphanumeric  or spaces
            clean_text = "".join(filter(lambda x: x.isalnum() or x.isspace(), f_read))
            # split the words
            words = clean_text.split()
            # read stop words document
            sw = read_file("Enter stopwords document: ")

            results, sw_flag, stem_flag = process_words(sw, words)
            output_data(f_read, sw_flag, stem_flag, results)

            # based upon the input value selected by user, perform actions
            while True:
                for key, v in switch_options.items():
                    print(key, "--", v)
                value = input("Please select from the above options:")
                if value == "0":
                    freq_analysis()
                elif value == "1":
                    results, sw_flag, stem_flag = process_words(sw, words)
                    output_data(f_read, sw_flag, stem_flag, results)
                elif value == "2":
                    show_previous_results()
                    break
                elif value == "3":
                    print("Exited from the analysis")
                    break
                else:
                    print("invalid input, Please enter a value between 0 and 3")
        else:
            raise Exception("Failed to process the file!")
    except Exception as e:
        print("Exception in frequency analysis:", e)


# applying stopwords setting
def process_stopwords(sw, words) -> Union[list, str]:
    while True:
        sw_flag = input(
            "Do you wish to exclude stopwords in your analysis? True or False: "
        )
        if sw_flag == "True":
            words = [word for word in words if word not in sw and word.isalnum]
            return words, sw_flag
        elif sw_flag == "False":
            return words, sw_flag
        else:
            print("Invalid input for stopwords, Please enter the correct option")


# appplying stemming of words setting
def stem_words(words) -> Union[dict, str]:
    while True:
        stem_flag = input(
            "Do you wish to extract stems of the words in your analysis? True or False: "
        )
        d = {}
        if stem_flag == "True":
            stems = []
            for word in words:
                # regexes to replace/remove suffixes according to the grammar rules
                word = re.sub(r"ZL$", "A", word)
                word = re.sub(r"PZL$", "AZ", word)
                word = re.sub(r"EZL$", "R", word)
                word = re.sub(r"(?:L|LZ|EVM|ZQ)$", "", word)
                stems.append(word)
            # extracting the root words and their inflections from the original text
            for s in stems:
                d[s] = []
                suff = tuple(["L", "LZ", "EVM", "ZQ"])
                if not s.endswith(suff):
                    for w in words:
                        if w.startswith(s) and not w.endswith(suff):
                            d[s].append(w)
                else:
                    pass
            d = {k: len(v) for k, v in d.items() if k in v}
            return d, stem_flag
        elif stem_flag == "False":
            for word in words:
                if word in d:
                    d[word] = d[word] + 1
                else:
                    d[word] = 1
            return d, stem_flag
        else:
            print("Invalid input for stemming flag, Please enter correct option")


# creates directories in current working dir
# it creates a nested folder structure with a timestamp attached to the subfolder name
# each subfolder has originaltext file and results file
def output_data(original_text, sw_flag, stem_flag, results) -> None:
    try:
        # folder path to be created
        path = "output/analysis-" + datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
        # check if path exists
        if not os.path.exists(path):
            os.makedirs(path)
        with open(os.path.join(path, "originaltext.txt"), "w") as f1:
            f1.write(original_text)
        with open(os.path.join(path, "results.txt"), "w") as f1:
            f1.write("\n\n---------------Results Analysis----------------------\n\n")
            f1.write(f"Excluded Stopwords: {sw_flag}\n")
            f1.write(f"Performed Stemming of words(removed suffixes): {stem_flag}\n\n")
            f1.write("Word Frequencies in supplied text: \n\n")
            f1.write(json.dumps(results, indent=4))
    except (OSError, Exception) as e:
        print("Error in writing the data to a file: ", e)


# this is to list the previous analysis results
def show_previous_results() -> None:
    try:
        print("To view the previous results, please navigate using the following paths")
        for root, dirs in os.walk("output"):
            for each in dirs:
                print(os.path.join(root, each))
    except OSError as e:
        print("Exception in listing the results: ", e)


freq_analysis()
